namespace Peloton_IDE.Presentation;

public partial record SecondViewModel(Entity Entity)
{
}
